import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;


public class XuLy {

	//Luu thong tin dang ky
	public void LuuThongTinTaiKhoan(HashMap<String, TaiKhoan> dsstk) {
		try {
			
			ObjectOutputStream ghi = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream("D://dsstk.ser")));
			ghi.writeObject(dsstk);
			ghi.close();
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	public HashMap<String, TaiKhoan> LayThongTinTaiKhoan() {
		HashMap<String, TaiKhoan> dsstk = new HashMap<String, TaiKhoan>();
		try {
			
			ObjectInputStream doc = new ObjectInputStream(new BufferedInputStream(new FileInputStream("D://dsstk.ser")));
			dsstk = (HashMap<String, TaiKhoan>) doc.readObject();
			doc.close();
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return dsstk;
	}
	
	//Xu lu dang ky
	public void DangKy() {
		HashMap<String, TaiKhoan> dstk = new HashMap<String, TaiKhoan>();
		dstk = LayThongTinTaiKhoan();
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Moi ban nhap ten dang nhap: ");
		String tenTK = scanner.nextLine();
		System.out.println("Moi ban nhap mat khau: ");
		String matkhau = scanner.nextLine();
		System.out.println("Moi ban nhap email: ");
		String email = scanner.nextLine();
		for (String key : dstk.keySet()) {
			if(key.equals(email))
			{
				System.out.println("Email da ton tai!");
			}
			if(dstk.get(key).getTenDangNhap().equals(tenTK))
			{
				System.out.println("Ten tai khoan da ton tai!");
			}
		}
		
		TaiKhoan tk = new TaiKhoan(tenTK, matkhau, email);
		dstk.put(email, tk);
		
		LuuThongTinTaiKhoan(dstk);
		
	}
	
	
	//Kiem tra dang nhap
	public void KiemTraDangNhap() {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("Moi ban nhap ten dang nhap: ");
		String tenTK = scanner.nextLine();
		System.out.println("Moi ban nhap mat khau: ");
		String matkhau = scanner.nextLine();
		HashMap<String, TaiKhoan> dstk = new HashMap<String, TaiKhoan>();
		dstk = LayThongTinTaiKhoan();
		for (String key : dstk.keySet()) {
		
			if(dstk.get(key).getTenDangNhap().equals(tenTK) && dstk.get(key).getMatKhau().equals(matkhau))
			{
				System.out.println("Dang nhap thanh cong!");
				System.out.println("Co luu thong tin dang nhap khong?");
				
				if(scanner.nextLine().equalsIgnoreCase("Co"))
				{
					
				}
			}
			
		}

		
	}
	
	
	//
	
}
